﻿namespace TakeHome04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.CB_Country = new System.Windows.Forms.ComboBox();
            this.CB_Team = new System.Windows.Forms.ComboBox();
            this.TB_NamaTeam = new System.Windows.Forms.TextBox();
            this.TB_City = new System.Windows.Forms.TextBox();
            this.TB_Country = new System.Windows.Forms.TextBox();
            this.TB_Position = new System.Windows.Forms.TextBox();
            this.TB_Number = new System.Windows.Forms.TextBox();
            this.TB_NamePlayer = new System.Windows.Forms.TextBox();
            this.BT_AddTeam = new System.Windows.Forms.Button();
            this.BT_AddPlayer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(110, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Soccer Team List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose Country :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Choose Team :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 195);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(392, 222);
            this.dataGridView1.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(471, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Add Team";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(326, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Team Name :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(326, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Team Country :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(326, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Team City : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(730, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Add Player";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(605, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "Team Name :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(605, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 16);
            this.label10.TabIndex = 10;
            this.label10.Text = "Team Number :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(605, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 16);
            this.label11.TabIndex = 11;
            this.label11.Text = "Player Position :";
            // 
            // CB_Country
            // 
            this.CB_Country.FormattingEnabled = true;
            this.CB_Country.Location = new System.Drawing.Point(142, 37);
            this.CB_Country.Name = "CB_Country";
            this.CB_Country.Size = new System.Drawing.Size(121, 24);
            this.CB_Country.TabIndex = 12;
            this.CB_Country.SelectedIndexChanged += new System.EventHandler(this.CB_Country_SelectedIndexChanged);
            // 
            // CB_Team
            // 
            this.CB_Team.FormattingEnabled = true;
            this.CB_Team.Location = new System.Drawing.Point(142, 78);
            this.CB_Team.Name = "CB_Team";
            this.CB_Team.Size = new System.Drawing.Size(121, 24);
            this.CB_Team.TabIndex = 13;
            this.CB_Team.SelectedIndexChanged += new System.EventHandler(this.CB_Team_SelectedIndexChanged);
            // 
            // TB_NamaTeam
            // 
            this.TB_NamaTeam.Location = new System.Drawing.Point(429, 37);
            this.TB_NamaTeam.Name = "TB_NamaTeam";
            this.TB_NamaTeam.Size = new System.Drawing.Size(100, 22);
            this.TB_NamaTeam.TabIndex = 14;
            // 
            // TB_City
            // 
            this.TB_City.Location = new System.Drawing.Point(429, 121);
            this.TB_City.Name = "TB_City";
            this.TB_City.Size = new System.Drawing.Size(100, 22);
            this.TB_City.TabIndex = 15;
            // 
            // TB_Country
            // 
            this.TB_Country.Location = new System.Drawing.Point(429, 78);
            this.TB_Country.Name = "TB_Country";
            this.TB_Country.Size = new System.Drawing.Size(100, 22);
            this.TB_Country.TabIndex = 16;
            // 
            // TB_Position
            // 
            this.TB_Position.Location = new System.Drawing.Point(718, 115);
            this.TB_Position.Name = "TB_Position";
            this.TB_Position.Size = new System.Drawing.Size(100, 22);
            this.TB_Position.TabIndex = 17;
            // 
            // TB_Number
            // 
            this.TB_Number.AcceptsReturn = true;
            this.TB_Number.Location = new System.Drawing.Point(718, 75);
            this.TB_Number.Name = "TB_Number";
            this.TB_Number.Size = new System.Drawing.Size(100, 22);
            this.TB_Number.TabIndex = 18;
            // 
            // TB_NamePlayer
            // 
            this.TB_NamePlayer.Location = new System.Drawing.Point(718, 37);
            this.TB_NamePlayer.Name = "TB_NamePlayer";
            this.TB_NamePlayer.Size = new System.Drawing.Size(100, 22);
            this.TB_NamePlayer.TabIndex = 19;
            // 
            // BT_AddTeam
            // 
            this.BT_AddTeam.Location = new System.Drawing.Point(429, 167);
            this.BT_AddTeam.Name = "BT_AddTeam";
            this.BT_AddTeam.Size = new System.Drawing.Size(75, 23);
            this.BT_AddTeam.TabIndex = 20;
            this.BT_AddTeam.Text = "ADD";
            this.BT_AddTeam.UseVisualStyleBackColor = true;
            // 
            // BT_AddPlayer
            // 
            this.BT_AddPlayer.Location = new System.Drawing.Point(718, 167);
            this.BT_AddPlayer.Name = "BT_AddPlayer";
            this.BT_AddPlayer.Size = new System.Drawing.Size(75, 23);
            this.BT_AddPlayer.TabIndex = 21;
            this.BT_AddPlayer.Text = "ADD";
            this.BT_AddPlayer.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 450);
            this.Controls.Add(this.BT_AddPlayer);
            this.Controls.Add(this.BT_AddTeam);
            this.Controls.Add(this.TB_NamePlayer);
            this.Controls.Add(this.TB_Number);
            this.Controls.Add(this.TB_Position);
            this.Controls.Add(this.TB_Country);
            this.Controls.Add(this.TB_City);
            this.Controls.Add(this.TB_NamaTeam);
            this.Controls.Add(this.CB_Team);
            this.Controls.Add(this.CB_Country);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox CB_Country;
        private System.Windows.Forms.ComboBox CB_Team;
        private System.Windows.Forms.TextBox TB_NamaTeam;
        private System.Windows.Forms.TextBox TB_City;
        private System.Windows.Forms.TextBox TB_Country;
        private System.Windows.Forms.TextBox TB_Position;
        private System.Windows.Forms.TextBox TB_Number;
        private System.Windows.Forms.TextBox TB_NamePlayer;
        private System.Windows.Forms.Button BT_AddTeam;
        private System.Windows.Forms.Button BT_AddPlayer;
    }
}

