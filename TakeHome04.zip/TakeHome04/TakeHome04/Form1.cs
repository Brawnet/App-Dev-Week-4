﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace TakeHome04
{
    public partial class Form1 : Form
    {
        DataTable dt;
        string SelectedCountry = "";
        string SelectedTeam = "";
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            CB_Country.Items.Add("Indonesia");
            CB_Country.Items.Add("Malaysia");
  
        }

        private void CB_Country_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedCountry = CB_Country.SelectedItem.ToString();
            if (SelectedCountry == "Indonesia")
            {
                CB_Team.Items.Clear();
                CB_Team.Items.Add("Madura United");
                CB_Team.Items.Add("Arema");
            }
            if (SelectedCountry == "Malaysia")
            {
                CB_Team.Items.Clear();
                CB_Team.Items.Add("Penang FC");
            }
        }

        private void CB_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedTeam = CB_Team.SelectedItem.ToString();
            if (SelectedTeam == "Madura United")
            {
                // Contoh daftar pemain Madura United
                var players = new List<string>
                {
                    "(59) - Satria Tama",
                    "(60) - Fawaid Ansory",
                    "(61) - Karisma Ramadhany",
                    "(81) - Wawan Hendrawan",
                    "(88) - Satria Tama",
                    "(2) - Guntur Ariyadi",
                    "(4) - Cleberson",
                    "(5) - Jacob Mahler",
                    "(16) - Rendika Rama",
                    "(19) - Fachruddin Aryanto",
                    "(20) - Novan Sasongko",
                    "(21) - Koko Ari",
                    "(22) - Alexvan Djin",
                    "(23) - Kartika Vedhayanto"
                };

                dataGridView1.Rows.Clear();

                foreach (var player in players)
                {
                    string[] playerDetails = player.Split('-');
                    dataGridView1.Rows.Add(playerDetails[0].Trim(), playerDetails[1].Trim());
                }
            }
        }
    }
}
